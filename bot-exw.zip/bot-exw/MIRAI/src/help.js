const help = (prefix) => { 
	return `
*•*¨*•.¸¸☆*   *Mirai-chan*  ﾟ•*¨*•.¸¸☆

➬  *${prefix}ownermenu*
➬  *${prefix}adminmenu*
➬  *${prefix}funmenu*
➬  *${prefix}mediamenu*
➬  *${prefix}kerangmenu*
➬  *${prefix}makermenu*
➬  *${prefix}othermenu*
➬  *${prefix}animemenu*
➬  *${prefix}nsfwmenu*
➬  *${prefix}vipmenu*

•*¨*•.¸¸☆*･ﾟ•*¨*•.¸¸☆*･ﾟ•*¨*•.¸¸☆

*➬ ${prefix}listmenu*
*➬ ${prefix}bugreport*
*➬ ${prefix}info*
*➬ ${prefix}owner*
*➬ ${prefix}request*
*➬ ${prefix}setprefix*
*➬ ${prefix}listblock*

•*¨*•.¸¸☆*･ﾟ•*¨*•.¸¸☆*･ﾟ•*¨*•.¸¸☆

*➬ ${prefix}iklan*
*➬ ${prefix}runtume*
*➬ ${prefix}rules*
*➬ ${prefix}tnc*
*➬ ${prefix}cekvip*

•*¨*•.¸¸☆*･ﾟ•*¨*•.¸¸☆*･ﾟ•*¨*•.¸¸☆

*➬ ${prefix}daftarvip*
*➬ ${prefix}addvip*
*➬ ${prefix}dellvip*
*➬ ${prefix}snk*
*➬ ${prefix}listpremium*
*➬ ${prefix}donate*
*➬ ${prefix}fitnah*
*➬ ${prefix}totaluser*
*➬ ${prefix}level*
*➬ ${prefix}leveling*
*➬ ${prefix}addbacot*
*➬ ${prefix}bacotlist*
*➬ ${prefix}resetbacot*
*➬ ${prefix}glass*

•*¨*•.¸¸☆*･ﾟ•*¨*•.¸¸☆*･ﾟ•*¨*•.¸¸☆
`
}
exports.help = help
